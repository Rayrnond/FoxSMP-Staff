package com.reflexian.staff.utilities.inventory;

import org.bukkit.entity.Player;

public interface Inventory {

    void init(Player player);

}