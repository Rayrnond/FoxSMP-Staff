package com.reflexian.staff.utilities;

public interface Queue<T>
{
    void execute(T response);
}
